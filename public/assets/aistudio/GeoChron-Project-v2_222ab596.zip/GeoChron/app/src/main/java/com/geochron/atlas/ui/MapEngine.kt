package com.geochron.atlas.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import com.geochron.atlas.data.GeoFeature
import com.geochron.atlas.data.MapGeometry
import com.geochron.atlas.data.RegionGeom
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sqrt

data class FitParams(val scale: Float, val originX: Float, val originY: Float, val cosMid: Float)

fun computeFit(geo: MapGeometry, w: Float, h: Float, pad: Float = 8f): FitParams {
    val midLat = (geo.minLat + geo.maxLat) / 2.0
    val cosMid = cos(Math.toRadians(midLat)).toFloat().coerceIn(0.25f, 1f)
    val effW = (geo.widthDeg * cosMid).toFloat()
    val effH = geo.heightDeg.toFloat()
    val scale = min((w - 2 * pad) / effW, (h - 2 * pad) / effH)
    return FitParams(scale, (w - effW * scale) / 2f, (h - effH * scale) / 2f, cosMid)
}

fun lonToX(geo: MapGeometry, fit: FitParams, lon: Double): Float =
    fit.originX + ((lon - geo.minLon) * fit.cosMid * fit.scale).toFloat()

fun latToY(geo: MapGeometry, fit: FitParams, lat: Double): Float =
    fit.originY + ((geo.maxLat - lat) * fit.scale).toFloat()

fun buildRegionPaths(geo: MapGeometry, fit: FitParams): Pair<Map<String, Path>, Map<String, Rect>> {
    val paths = LinkedHashMap<String, Path>()
    val boxes = HashMap<String, Rect>()
    for (region in geo.regions) {
        val path = Path()
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (poly in region.polys) for (ring in poly) {
            var i = 0
            while (i + 1 < ring.size) {
                val x = lonToX(geo, fit, ring[i].toDouble())
                val y = latToY(geo, fit, ring[i + 1].toDouble())
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                if (x < minX) minX = x; if (x > maxX) maxX = x
                if (y < minY) minY = y; if (y > maxY) maxY = y
                i += 2
            }
            path.close()
        }
        paths[region.name] = path
        boxes[region.name] = Rect(minX, minY, maxX, maxY)
    }
    return paths to boxes
}

data class EmpireLayer(val datasetId: String, val name: String, val color: Color, val poly: List<Pair<Double, Double>>)
data class MapFocus(val lon: Double, val lat: Double, val zoom: Float, val signal: Int)

fun categoryColor(cat: String): Color = when (cat) {
    "RIVER" -> Color(0xFF1976D2)
    "MOUNTAIN" -> Color(0xFF795548)
    "DESERT" -> Color(0xFFE0A526)
    "LAKE" -> Color(0xFF039BE5)
    "WATERFALL" -> Color(0xFF00ACC1)
    "PEAK" -> Color(0xFF5D4037)
    "PASS" -> Color(0xFFFB8C00)
    "DAM" -> Color(0xFF3949AB)
    "PARK" -> Color(0xFF2E7D32)
    "CITY" -> Color(0xFFC62828)
    "OCEAN" -> Color(0xFF1565C0)
    "STRAIT" -> Color(0xFF00838F)
    "VOLCANO" -> Color(0xFFD84315)
    "POWER" -> Color(0xFF8E24AA)
    "ISLAND" -> Color(0xFF00897B)
    "SITE" -> Color(0xFF4E342E)
    else -> Color(0xFF6A1B9A)
}

private fun ringContainsPairs(ring: List<Pair<Double, Double>>, x: Double, y: Double): Boolean {
    var inside = false
    var j = ring.size - 1
    for (i in ring.indices) {
        val xi = ring[i].first; val yi = ring[i].second
        val xj = ring[j].first; val yj = ring[j].second
        if ((yi > y) != (yj > y)) {
            val xInt = (xj - xi) * (y - yi) / (yj - yi) + xi
            if (x < xInt) inside = !inside
        }
        j = i
    }
    return inside
}

private fun distToSegment(px: Double, py: Double, ax: Double, ay: Double, bx: Double, by: Double): Double {
    val dx = bx - ax; val dy = by - ay
    val len2 = dx * dx + dy * dy
    val tt = if (len2 == 0.0) 0.0 else (((px - ax) * dx + (py - ay) * dy) / len2).coerceIn(0.0, 1.0)
    val cx = ax + tt * dx; val cy = ay + tt * dy
    return sqrt((px - cx) * (px - cx) + (py - cy) * (py - cy))
}

@Composable
fun AtlasMap(
    geo: MapGeometry,
    dark: Boolean,
    features: List<GeoFeature>,
    empireLayers: List<EmpireLayer> = emptyList(),
    highlightRegion: String? = null,
    selectedFeatureId: String? = null,
    regionLabels: Map<String, String> = emptyMap(),
    focus: MapFocus? = null,
    interactive: Boolean = true,
    onRegionTap: (RegionGeom) -> Unit = {},
    onFeatureTap: (GeoFeature) -> Unit = {},
    onEmpireTap: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var size by remember { mutableStateOf(IntSize.Zero) }
    var zoom by remember(geo) { mutableFloatStateOf(1f) }
    var offset by remember(geo) { mutableStateOf(Offset.Zero) }

    val fit = remember(geo, size) { if (size.width == 0) null else computeFit(geo, size.width.toFloat(), size.height.toFloat()) }
    val built = remember(geo, fit) { if (fit == null) null else buildRegionPaths(geo, fit) }

    LaunchedEffect(focus?.signal) {
        val f = focus ?: return@LaunchedEffect
        val ft = fit ?: return@LaunchedEffect
        zoom = f.zoom
        val bx = lonToX(geo, ft, f.lon)
        val by = latToY(geo, ft, f.lat)
        offset = Offset(size.width / 2f - bx * zoom, size.height / 2f - by * zoom)
    }

    val gestureModifier = if (interactive) {
        Modifier.pointerInput(geo, fit) {
            val slop = viewConfiguration.touchSlop
            awaitPointerEventScope {
                while (true) {
                    val downEvent = awaitPointerEvent(PointerEventPass.Main)
                    val down = downEvent.changes.firstOrNull { it.pressed } ?: continue
                    var totalMove = 0f
                    var pinching = false
                    var prevDist = 0f
                    var prevCentroid = Offset.Zero
                    var up = false
                    while (!up) {
                        val event = awaitPointerEvent(PointerEventPass.Main)
                        val pressed = event.changes.filter { it.pressed }
                        if (pressed.isEmpty()) {
                            up = true
                        } else if (pressed.size >= 2) {
                            pinching = true
                            val a = pressed[0].position; val b = pressed[1].position
                            val centroid = (a + b) / 2f
                            val dist = (a - b).getDistance()
                            if (prevDist > 0f) {
                                val factor = (dist / prevDist).coerceIn(0.8f, 1.25f)
                                val newZoom = (zoom * factor).coerceIn(1f, 9f)
                                offset = centroid - (centroid - offset) * (newZoom / zoom)
                                zoom = newZoom
                                offset += (centroid - prevCentroid)
                            }
                            prevDist = dist; prevCentroid = centroid
                            event.changes.forEach { it.consume() }
                        } else {
                            val ch = pressed[0]
                            val delta = ch.position - ch.previousPosition
                            totalMove += delta.getDistance()
                            if (pinching || totalMove > slop) {
                                if (!pinching) { offset += delta; ch.consume() }
                            }
                        }
                        if (event.changes.all { !it.pressed }) up = true
                    }
                    if (!pinching && totalMove <= slop && fit != null) {
                        val base = (down.position - offset) / zoom
                        val lon = geo.minLon + (base.x - fit.originX) / (fit.scale * fit.cosMid)
                        val lat = geo.maxLat - (base.y - fit.originY) / fit.scale
                        handleTap(geo, features, empireLayers, lon, lat, onFeatureTap, onEmpireTap, onRegionTap)
                    }
                }
            }
        }
    } else Modifier

    Canvas(modifier = modifier.onSizeChanged { size = it }.then(gestureModifier)) {
        // Ocean background
        drawRect(
            brush = Brush.verticalGradient(
                if (dark) listOf(Color(0xFF0D2233), Color(0xFF14334D)) else listOf(Color(0xFFCDEBF8), Color(0xFF9ED2EE))
            ),
            size = this.size
        )
        val f = fit ?: return@Canvas
        val (paths, boxes) = built ?: return@Canvas
        val tints = if (dark) REGION_TINTS_DARK else REGION_TINTS
        withTransform({
            translate(offset.x, offset.y)
            scale(zoom, zoom, Offset.Zero)
        }) {
            // Regions (states / countries)
            var idx = 0
            for ((name, path) in paths) {
                val fill = when {
                    name == highlightRegion -> Color(0xFFE53935)
                    else -> tints[idx % tints.size]
                }
                drawPath(path, color = fill, style = Fill)
                idx++
            }
            for ((_, path) in paths) {
                drawPath(path, color = if (dark) Color(0xFF0E1621) else Color.White, style = Stroke(width = 1.1f / zoom))
            }
            // Empire overlays
            for (layer in empireLayers) {
                val path = Path()
                layer.poly.forEachIndexed { i, (lon, lat) ->
                    val x = lonToX(geo, f, lon); val y = latToY(geo, f, lat)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                drawPath(path, color = layer.color.copy(alpha = 0.55f), style = Fill)
                drawPath(path, color = layer.color, style = Stroke(width = 2.2f / zoom))
            }
            // Lines & area features
            for (feature in features) {
                when (feature.geomType) {
                    "line" -> {
                        val path = Path()
                        feature.coords.forEachIndexed { i, (lon, lat) ->
                            val x = lonToX(geo, f, lon); val y = latToY(geo, f, lat)
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        val isSelLine = feature.id == selectedFeatureId
                        drawPath(
                            path, color = if (isSelLine) Color(0xFFF2994A) else categoryColor(feature.cat),
                            style = Stroke(width = (if (isSelLine) 7f else if (feature.cat == "MOUNTAIN") 5f else 3.2f) / zoom, cap = StrokeCap.Round)
                        )
                    }
                    "poly" -> {
                        val path = Path()
                        feature.coords.forEachIndexed { i, (lon, lat) ->
                            val x = lonToX(geo, f, lon); val y = latToY(geo, f, lat)
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        path.close()
                        val isSelPoly = feature.id == selectedFeatureId
                        drawPath(path, color = (if (isSelPoly) Color(0xFFF2994A) else categoryColor(feature.cat)).copy(alpha = 0.55f), style = Fill)
                        drawPath(path, color = if (isSelPoly) Color(0xFFF2994A) else categoryColor(feature.cat), style = Stroke(width = (if (isSelPoly) 3f else 1.4f) / zoom))
                    }
                }
            }
            // Point markers
            for (feature in features) {
                if (feature.geomType != "point") continue
                val (lon, lat) = feature.coords.first()
                val cx = lonToX(geo, f, lon); val cy = latToY(geo, f, lat)
                val isSel = feature.id == selectedFeatureId
                val r = (if (isSel) 11f else 7f) / zoom
                if (isSel) drawCircle(Color.White.copy(alpha = 0.6f), radius = r * 1.9f, center = Offset(cx, cy))
                drawCircle(categoryColor(feature.cat), radius = r, center = Offset(cx, cy))
                drawCircle(Color.White, radius = r, center = Offset(cx, cy), style = Stroke(width = 1.8f / zoom))
                drawCircle(Color.White, radius = r * 0.38f, center = Offset(cx, cy))
            }
            // Labels
            val paint = Paint().apply { isAntiAlias = true; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
            drawContext.canvas.nativeCanvas.apply {
                if (zoom >= 1.15f) {
                    for ((name, label) in regionLabels) {
                        val box = boxes[name] ?: continue
                        var fs = min(box.width / (label.length * 0.62f), box.height * 0.8f)
                        fs = min(fs, 26f / zoom * 1.6f)
                        if (fs < 6.5f / zoom) continue
                        paint.textSize = fs
                        paint.color = (if (dark) Color(0xFFE8EEF4) else Color(0xFF37474F)).copy(alpha = 0.9f).toArgb()
                        val region = geo.regions.firstOrNull { it.name == name } ?: continue
                        val cx = lonToX(geo, f, region.centroid.first)
                        val cy = latToY(geo, f, region.centroid.second)
                        drawText(label, cx, cy + fs * 0.35f, paint)
                    }
                }
                // Ocean / sea labels (always, large italic-ish blue text)
                for (feature in features) {
                    if (feature.cat != "OCEAN") continue
                    val (lon, lat) = feature.coords.first()
                    paint.textSize = 15f / zoom * 1.35f
                    paint.color = (if (dark) Color(0xFF9CC8E8) else Color(0xFF1565C0)).copy(alpha = 0.75f).toArgb()
                    drawText(feature.hi, lonToX(geo, f, lon), latToY(geo, f, lat), paint)
                }
            }
        }
    }
}

private fun handleTap(
    geo: MapGeometry,
    features: List<GeoFeature>,
    empires: List<EmpireLayer>,
    lon: Double, lat: Double,
    onFeatureTap: (GeoFeature) -> Unit,
    onEmpireTap: (String) -> Unit,
    onRegionTap: (RegionGeom) -> Unit
) {
    // 1) point features — nearest within ~1.6 degrees
    var bestPoint: GeoFeature? = null; var bestD = 1.6
    for (f in features) {
        if (f.geomType != "point") continue
        val (flon, flat) = f.coords.first()
        val d = sqrt((flon - lon) * (flon - lon) + (flat - lat) * (flat - lat))
        if (d < bestD) { bestD = d; bestPoint = f }
    }
    if (bestPoint != null) { onFeatureTap(bestPoint); return }
    // 2) line features — within ~0.7 degrees of any segment
    var bestLine: GeoFeature? = null; var bestLD = 0.7
    for (f in features) {
        if (f.geomType != "line") continue
        for (i in 0 until f.coords.size - 1) {
            val a = f.coords[i]; val b = f.coords[i + 1]
            val d = distToSegment(lon, lat, a.first, a.second, b.first, b.second)
            if (d < bestLD) { bestLD = d; bestLine = f }
        }
    }
    if (bestLine != null) { onFeatureTap(bestLine); return }
    // 3) empire polygons
    for (layer in empires) {
        if (ringContainsPairs(layer.poly, lon, lat)) { onEmpireTap(layer.datasetId); return }
    }
    // 4) area features (deserts)
    for (f in features) {
        if (f.geomType == "poly" && ringContainsPairs(f.coords, lon, lat)) { onFeatureTap(f); return }
    }
    // 5) regions
    geo.hitTest(lon, lat)?.let { onRegionTap(it) }
}
