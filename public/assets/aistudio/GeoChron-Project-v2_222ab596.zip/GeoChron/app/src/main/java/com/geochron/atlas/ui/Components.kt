package com.geochron.atlas.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.geochron.atlas.AppViewModel
import com.geochron.atlas.data.AtlasData
import com.geochron.atlas.data.GeoFeature
import com.geochron.atlas.data.HistoryDataset
import com.geochron.atlas.data.HistoryEvent
import com.geochron.atlas.data.PlaceInfo
import com.geochron.atlas.data.RegionGeom
import com.geochron.atlas.data.categoryLabel

// ---------------- PlaceInfo builders ----------------

fun placeFromFeature(f: GeoFeature): PlaceInfo {
    val (lon, lat) = f.anchor
    return PlaceInfo(
        id = f.id, nameHi = f.hi, nameEn = f.en,
        categoryHi = categoryLabel(f.cat, true), categoryEn = categoryLabel(f.cat, false),
        infoHi = f.infoHi, infoEn = f.infoEn, factHi = f.factHi,
        dateLabel = "", source = f.source, scope = f.scope, lon = lon, lat = lat
    )
}

fun placeFromRegion(data: AtlasData, scope: String, region: RegionGeom): PlaceInfo {
    if (scope == "india") {
        val info = data.statesInfo[region.name]
        return PlaceInfo(
            id = "region_india_" + region.name,
            nameHi = info?.hi ?: region.name, nameEn = region.name,
            categoryHi = categoryLabel("STATE", true), categoryEn = categoryLabel("STATE", false),
            infoHi = if (info != null) "राजधानी: ${info.capitalHi} (${info.capitalEn})" else "",
            infoEn = if (info != null) "Capital: ${info.capitalEn}" else "",
            factHi = info?.factHi ?: "",
            dateLabel = "", source = "Natural Earth / सार्वजनिक GeoJSON डेटा",
            scope = "india", lon = region.centroid.first, lat = region.centroid.second
        )
    }
    return PlaceInfo(
        id = "region_world_" + region.name,
        nameHi = data.countriesHi[region.name] ?: region.name, nameEn = region.name,
        categoryHi = categoryLabel("COUNTRY", true), categoryEn = categoryLabel("COUNTRY", false),
        infoHi = "", infoEn = "", factHi = "",
        dateLabel = "", source = "Natural Earth (public domain)",
        scope = "world", lon = region.centroid.first, lat = region.centroid.second
    )
}

fun placeFromEvent(ds: HistoryDataset, ev: HistoryEvent): PlaceInfo = PlaceInfo(
    id = "event_" + ds.id + "_" + ev.en,
    nameHi = ev.hi, nameEn = ev.en,
    categoryHi = categoryLabel("EVENT", true), categoryEn = categoryLabel("EVENT", false),
    infoHi = ev.infoHi, infoEn = ev.infoEn, factHi = ev.factHi,
    dateLabel = ev.yearLabel, source = ds.source, scope = ds.scope, lon = ev.lon, lat = ev.lat
)

fun placeFromDataset(ds: HistoryDataset): PlaceInfo {
    val (lon, lat) = ds.poly?.firstOrNull() ?: (0.0 to 0.0)
    return PlaceInfo(
        id = "empire_" + ds.id, nameHi = ds.hi, nameEn = ds.en,
        categoryHi = categoryLabel("EMPIRE", true), categoryEn = categoryLabel("EMPIRE", false),
        infoHi = ds.summaryHi + "\n\n⚠ सीमा की सटीकता: " + ds.confidence,
        infoEn = ds.summaryEn,
        factHi = "", dateLabel = ds.periodHi, source = ds.source,
        scope = ds.scope, lon = lon, lat = lat
    )
}

fun parseHexColor(hex: String): Color = runCatching {
    val v = hex.removePrefix("#").toLong(16)
    Color(((v shr 16) and 0xFF).toInt(), ((v shr 8) and 0xFF).toInt(), (v and 0xFF).toInt())
}.getOrDefault(Color(0xFFF2994A))

// ---------------- Info bottom sheet ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaceSheet(vm: AppViewModel) {
    val place by vm.selected.collectAsState()
    val hindi by vm.hindi.collectAsState()
    val bookmarkIds by vm.bookmarkIds.collectAsState()
    val current = place ?: return
    val sheetState = rememberModalBottomSheetState()
    var showNoteDialog by remember(current.id) { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = { vm.select(null) }, sheetState = sheetState) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(current.nameHi, fontWeight = FontWeight.Bold, fontSize = 24.sp)
            Text(current.nameEn, color = Color.Gray, fontSize = 15.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                if (hindi) current.categoryHi else current.categoryEn,
                color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.background(AtlasBlue, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp)
            )
            Spacer(Modifier.height(12.dp))
            if (current.dateLabel.isNotBlank()) InfoRow(Icons.Filled.Schedule, t(hindi, "समय / काल", "Period"), current.dateLabel)
            val info = if (hindi) current.infoHi else current.infoEn
            if (info.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(info, fontSize = 14.5.sp, lineHeight = 21.sp)
            }
            if (current.factHi.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFFFFF4D6), RoundedCornerShape(10.dp)).padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFE0A526))
                    Column(Modifier.padding(start = 8.dp)) {
                        Text(t(hindi, "महत्वपूर्ण तथ्य", "Important fact"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(current.factHi, fontSize = 13.5.sp)
                    }
                }
            }
            if (current.source.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                InfoRow(Icons.Filled.Place, t(hindi, "स्रोत", "Source"), current.source)
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val isBookmarked = bookmarkIds.contains(current.id)
                Button(onClick = { vm.toggleBookmark(current) }, modifier = Modifier.weight(1f)) {
                    Icon(if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder, contentDescription = null)
                    Text(
                        if (isBookmarked) t(hindi, "सेव है", "Saved") else t(hindi, "बुकमार्क करें", "Add to Bookmarks"),
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
                OutlinedButton(onClick = { showNoteDialog = true }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.EditNote, contentDescription = null)
                    Text(t(hindi, "नोट लिखें", "Add note"), modifier = Modifier.padding(start = 6.dp))
                }
            }
        }
    }

    if (showNoteDialog) {
        var title by remember { mutableStateOf(current.nameHi) }
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNoteDialog = false },
            title = { Text(t(hindi, "मेरा नोट", "My note")) },
            text = {
                Column {
                    OutlinedTextField(title, { title = it }, label = { Text(t(hindi, "शीर्षक", "Title")) }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(text, { text = it }, label = { Text(t(hindi, "नोट लिखें…", "Write your note…")) }, minLines = 3)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (text.isNotBlank()) vm.saveNote(title, text, current.id)
                    showNoteDialog = false
                }) { Text(t(hindi, "सेव", "Save")) }
            },
            dismissButton = { TextButton(onClick = { showNoteDialog = false }) { Text(t(hindi, "रद्द", "Cancel")) } }
        )
    }
}

@Composable
private fun InfoRow(icon: ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(vertical = 3.dp)) {
        Icon(icon, contentDescription = null, tint = AtlasBlue)
        Column(Modifier.padding(start = 10.dp)) {
            Text(label, color = Color.Gray, fontSize = 12.sp)
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}
