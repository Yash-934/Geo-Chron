package com.geochron.atlas.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.geochron.atlas.AppViewModel
import com.geochron.atlas.data.AtlasData
import com.geochron.atlas.data.PlaceInfo

/** Find a full PlaceInfo for any stored id (feature / region / event / empire). */
fun resolvePlace(data: AtlasData, id: String): PlaceInfo? {
    data.allFeatures().firstOrNull { it.id == id }?.let { return placeFromFeature(it) }
    for (ds in data.history) {
        if (id == "empire_" + ds.id) return placeFromDataset(ds)
        for (ev in ds.events) if (id == "event_" + ds.id + "_" + ev.en) return placeFromEvent(ds, ev)
    }
    if (id.startsWith("region_india_")) {
        val name = id.removePrefix("region_india_")
        data.boundaries["india"]?.regions?.firstOrNull { it.name == name }?.let { return placeFromRegion(data, "india", it) }
    }
    if (id.startsWith("region_world_")) {
        val name = id.removePrefix("region_world_")
        data.boundaries["world"]?.regions?.firstOrNull { it.name == name }?.let { return placeFromRegion(data, "world", it) }
    }
    return null
}

// ---------------- HOME ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(nav: NavController, vm: AppViewModel) {
    val data by vm.data.collectAsState()
    val hindi by vm.hindi.collectAsState()
    val recents by vm.recents.collectAsState()
    val bookmarks by vm.bookmarks.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("GeoChron") },
                actions = {
                    IconButton(onClick = { nav.navigate("settings") }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepNavy, titleContentColor = Color.White, actionIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        if (data == null) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text(t(hindi, "एटलस लोड हो रहा है…", "Loading the atlas…"))
                }
            }
            return@Scaffold
        }
        val d = data!!
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header banner (like the design mockup)
            Box(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(DeepNavy, AtlasBlue)), RoundedCornerShape(18.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Text("🌍 GeoChron", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
                    Text(
                        t(hindi, "इंटरएक्टिव भूगोल और इतिहास एटलस", "Interactive Geography & History Atlas"),
                        color = Color(0xFFCFE7F7), fontSize = 14.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        t(hindi, "सीखें • खोजें • समझें", "Learn • Explore • Understand"),
                        color = AccentOrange, fontWeight = FontWeight.Bold, fontSize = 13.sp
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeCard(Icons.Filled.Public, Color(0xFF1565C0), t(hindi, "भूगोल", "Geography"), t(hindi, "भूगोल का संसार", "World of geography"), Modifier.weight(1f)) {
                    vm.exploreScope = "india"; nav.navigate("explore")
                }
                HomeCard(Icons.Filled.History, Color(0xFFEF6C00), t(hindi, "इतिहास", "History"), t(hindi, "इतिहास की यात्रा", "Journey through time"), Modifier.weight(1f)) {
                    nav.navigate("timeline")
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeCard(Icons.Filled.EmojiEvents, Color(0xFF2E7D32), t(hindi, "मैप क्विज़", "Map Quiz"), t(hindi, "मैप पर आधारित प्रश्न", "Map-based questions"), Modifier.weight(1f)) {
                    nav.navigate("quiz")
                }
                HomeCard(Icons.Filled.Bookmark, Color(0xFF6A1B9A), t(hindi, "बुकमार्क", "Bookmarks"), t(hindi, "मेरी सेवाएँ (${bookmarks.size})", "My saves (${bookmarks.size})"), Modifier.weight(1f)) {
                    nav.navigate("bookmarks")
                }
            }

            if (d.notesChapters.isNotEmpty()) {
                HomeCard(Icons.Filled.MenuBook, Color(0xFF00897B), t(hindi, "Parmar Geography नोट्स", "Parmar Geography Notes"),
                    t(hindi, "${d.notesChapters.size} अध्याय • ${d.notesChapters.sumOf { it.bullets.size }} तथ्य • आपके PDF से", "${d.notesChapters.size} chapters • ${d.notesChapters.sumOf { it.bullets.size }} facts • from your PDF"),
                    Modifier.fillMaxWidth()) {
                    nav.navigate("notes")
                }
            }

            Text(t(hindi, "त्वरित पहुँच (Quick Access)", "Quick Access"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAccess("🗺️", t(hindi, "भारत का मानचित्र", "Map of India"), Modifier.weight(1f)) {
                    vm.exploreScope = "india"; nav.navigate("explore")
                }
                QuickAccess("🌐", t(hindi, "विश्व का मानचित्र", "World map"), Modifier.weight(1f)) {
                    vm.exploreScope = "world"; nav.navigate("explore")
                }
                QuickAccess("🕰️", t(hindi, "समय रेखा", "Timeline"), Modifier.weight(1f)) {
                    nav.navigate("timeline")
                }
            }

            // Did you know — fact of the day, deterministic by date
            val facts = remember(d) {
                (d.allFeatures().map { it.factHi }.filter { it.isNotBlank() } +
                    d.statesInfo.values.map { it.factHi }.filter { it.isNotBlank() })
            }
            if (facts.isNotEmpty()) {
                val dayIndex = (System.currentTimeMillis() / 86_400_000L % facts.size).toInt()
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
                    shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(14.dp)) {
                        Icon(Icons.Filled.Lightbulb, contentDescription = null, tint = Color(0xFFE0A526))
                        Column(Modifier.padding(start = 10.dp)) {
                            Text(t(hindi, "क्या आप जानते हैं?", "Did you know?"), fontWeight = FontWeight.Bold, color = Color(0xFF8D6E00))
                            Text(facts[dayIndex], fontSize = 13.5.sp, color = Color(0xFF5D4A12))
                        }
                    }
                }
            }

            if (recents.isNotEmpty()) {
                Text(t(hindi, "हाल ही में देखे गए", "Recently viewed"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    recents.take(5).forEach { r ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable {
                                resolvePlace(d, r.id)?.let { p ->
                                    vm.focusPlace = p; vm.exploreScope = p.scope; nav.navigate("explore")
                                }
                            },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(Modifier.padding(12.dp)) {
                                Icon(Icons.Filled.Map, contentDescription = null, tint = AtlasBlue)
                                Column(Modifier.padding(start = 10.dp)) {
                                    Text(if (hindi) r.nameHi else r.nameEn, fontWeight = FontWeight.Medium)
                                    Text(if (r.scope == "india") t(hindi, "भारत एटलस", "India atlas") else t(hindi, "विश्व एटलस", "World atlas"), color = Color.Gray, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun HomeCard(icon: ImageVector, color: Color, title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.height(118.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = color),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(8.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(subtitle, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun QuickAccess(emoji: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 20.sp)
            Text(label, fontSize = 11.5.sp, fontWeight = FontWeight.Medium, maxLines = 2)
        }
    }
}

// ---------------- EXPLORE ----------------

private val LAYER_GROUPS: List<Pair<String, List<String>>> = listOf(
    "भौगोलिक (Geographic)" to listOf("RIVER", "MOUNTAIN", "DESERT"),
    "प्राकृतिक (Natural)" to listOf("LAKE", "WATERFALL", "PEAK", "PASS", "PARK"),
    "मानव निर्मित (Human-made)" to listOf("DAM", "CITY", "STRAIT")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(nav: NavController, vm: AppViewModel) {
    val data by vm.data.collectAsState()
    val hindi by vm.hindi.collectAsState()
    val dark by vm.dark.collectAsState()
    val selected by vm.selected.collectAsState()

    var scope by remember { mutableStateOf(vm.exploreScope) }
    val layers = remember { mutableStateMapOf<String, Boolean>() }
    var showLayers by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var focus by remember { mutableStateOf<MapFocus?>(null) }
    var focusSignal by remember { mutableIntStateOf(0) }

    val d = data
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(t(hindi, "भूगोल एटलस", "Geography Atlas")) },
                actions = {
                    IconButton(onClick = { showSearch = !showSearch }) { Icon(Icons.Filled.Search, contentDescription = "Search") }
                    IconButton(onClick = { showLayers = true }) { Icon(Icons.Filled.Layers, contentDescription = "Layers") }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepNavy, titleContentColor = Color.White, actionIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        if (d == null) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        val geo = d.boundaries[scope]!!
        val allScopeFeatures = d.featuresFor(scope)
        val visibleFeatures = allScopeFeatures.filter { f ->
            when (f.cat) {
                "OCEAN" -> true
                else -> layers[f.cat] ?: true
            }
        }
        val regionLabels = remember(d, scope, hindi) {
            if (scope == "india") d.statesInfo.mapValues { (k, v) -> if (hindi) v.hi else k }.mapKeys { it.key }
                .let { m -> geo.regions.associate { r -> r.name to (m[r.name] ?: r.name) } }
            else geo.regions.associate { r -> r.name to (if (hindi) (d.countriesHi[r.name] ?: r.name) else r.name) }
        }

        // Focus request coming from Home / Bookmarks / Recents
        LaunchedEffect(d, vm.focusPlace) {
            val p = vm.focusPlace ?: return@LaunchedEffect
            scope = p.scope
            focusSignal++
            focus = MapFocus(p.lon, p.lat, 2.4f, focusSignal)
            vm.select(p)
            vm.focusPlace = null
        }

        Column(Modifier.padding(padding).fillMaxSize()) {
            // Scope switch — भारत | विश्व
            Row(Modifier.fillMaxWidth().background(DeepNavy).padding(horizontal = 14.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScopeButton(t(hindi, "भारत", "India"), scope == "india", Modifier.weight(1f)) { scope = "india" }
                ScopeButton(t(hindi, "विश्व", "World"), scope == "world", Modifier.weight(1f)) { scope = "world" }
                IconButton(onClick = {
                    focusSignal++
                    val c = geoCenter(geo)
                    focus = MapFocus(c.first, c.second, 1f, focusSignal)
                }) { Icon(Icons.Filled.CenterFocusStrong, contentDescription = "Reset view", tint = Color.White) }
            }

            if (showSearch) {
                Column(Modifier.fillMaxWidth().background(Color.White).padding(10.dp)) {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        placeholder = { Text(t(hindi, "स्थान खोजें — हिंदी या English में…", "Search places — Hindi or English…")) },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    if (query.length >= 2) {
                        val results = remember(query, d, scope) { searchPlaces(d, query).take(8) }
                        LazyColumn(Modifier.fillMaxWidth().height(220.dp)) {
                            items(results) { p ->
                                Row(
                                    Modifier.fillMaxWidth().clickable {
                                        vm.recordSearch(query)
                                        scope = p.scope
                                        focusSignal++
                                        focus = MapFocus(p.lon, p.lat, 2.4f, focusSignal)
                                        vm.select(p)
                                        showSearch = false
                                    }.padding(10.dp)
                                ) {
                                    Icon(Icons.Filled.SwitchAccount, contentDescription = null, tint = AtlasBlue)
                                    Column(Modifier.padding(start = 8.dp)) {
                                        Text(if (hindi) p.nameHi else p.nameEn, fontWeight = FontWeight.Medium)
                                        Text(if (hindi) p.categoryHi else p.categoryEn, color = Color.Gray, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                AtlasMap(
                    geo = geo, dark = dark,
                    features = visibleFeatures,
                    highlightRegion = null,
                    selectedFeatureId = selected?.id,
                    regionLabels = regionLabels,
                    focus = focus,
                    onRegionTap = { region -> vm.select(placeFromRegion(d, scope, region)) },
                    onFeatureTap = { f -> vm.select(placeFromFeature(f)) },
                    modifier = Modifier.fillMaxSize()
                )
                // Legend chips
                Row(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.92f))
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val cats = visibleFeatures.map { it.cat }.distinct()
                    for (cat in cats) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).background(categoryColor(cat), RoundedCornerShape(3.dp)))
                            Text(
                                com.geochron.atlas.data.categoryLabel(cat, hindi),
                                fontSize = 11.5.sp, modifier = Modifier.padding(start = 4.dp)
                            )
                        }
                    }
                }
            }
            Text(
                t(hindi, "किसी स्थान पर टैप करें • पिंच से ज़ूम करें", "Tap a place for details • Pinch to zoom"),
                color = Color.Gray, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
            )
        }

        if (showLayers) {
            ModalBottomSheet(onDismissRequest = { showLayers = false }) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 30.dp)) {
                    Text("🗺️ " + t(hindi, "मैप लेयर्स", "Map Layers"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    for ((group, cats) in LAYER_GROUPS) {
                        val present = cats.filter { cat -> allScopeFeatures.any { it.cat == cat } }
                        if (present.isEmpty()) continue
                        Text(group, fontWeight = FontWeight.Bold, color = AtlasBlue, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                        for (cat in present) {
                            val on = layers[cat] ?: true
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(12.dp).background(categoryColor(cat), RoundedCornerShape(3.dp)))
                                Text(
                                    com.geochron.atlas.data.categoryLabel(cat, hindi),
                                    modifier = Modifier.padding(start = 10.dp).weight(1f)
                                )
                                Switch(checked = on, onCheckedChange = { layers[cat] = it })
                            }
                        }
                    }
                }
            }
        }
        PlaceSheet(vm)
    }
}

@Composable
private fun ScopeButton(label: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    if (active) {
        Button(onClick = onClick, modifier = modifier, colors = ButtonDefaults.buttonColors(containerColor = AtlasBlue)) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text(label) }
    }
}

private fun geoCenter(geo: com.geochron.atlas.data.MapGeometry): Pair<Double, Double> =
    ((geo.minLon + geo.maxLon) / 2) to ((geo.minLat + geo.maxLat) / 2)

fun searchPlaces(data: AtlasData, query: String): List<PlaceInfo> {
    val q = query.trim().lowercase()
    if (q.isEmpty()) return emptyList()
    val out = ArrayList<PlaceInfo>()
    for (f in data.allFeatures()) {
        if (f.en.lowercase().contains(q) || f.hi.contains(query.trim())) out.add(placeFromFeature(f))
    }
    for ((name, info) in data.statesInfo) {
        if (name.lowercase().contains(q) || info.hi.contains(query.trim()) || info.capitalEn.lowercase().contains(q)) {
            data.boundaries["india"]?.regions?.firstOrNull { it.name == name }?.let { out.add(placeFromRegion(data, "india", it)) }
        }
    }
    for (region in data.boundaries["world"]?.regions ?: emptyList()) {
        val hi = data.countriesHi[region.name] ?: ""
        if (region.name.lowercase().contains(q) || hi.contains(query.trim())) out.add(placeFromRegion(data, "world", region))
    }
    for (ds in data.history) {
        if (ds.en.lowercase().contains(q) || ds.hi.contains(query.trim())) out.add(placeFromDataset(ds))
        for (ev in ds.events) {
            if (ev.en.lowercase().contains(q) || ev.hi.contains(query.trim())) out.add(placeFromEvent(ds, ev))
        }
    }
    return out.distinctBy { it.id }
}
