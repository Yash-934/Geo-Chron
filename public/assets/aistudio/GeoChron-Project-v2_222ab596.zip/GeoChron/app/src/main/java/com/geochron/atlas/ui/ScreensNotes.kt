package com.geochron.atlas.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.geochron.atlas.AppViewModel
import com.geochron.atlas.data.NotesChapter

/** Parmar Geography study notes: chapter list + chapter reader (content extracted from the user's PDF). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesScreen(nav: NavController, vm: AppViewModel) {
    val data by vm.data.collectAsState()
    val hindi by vm.hindi.collectAsState()
    var selected by remember { mutableStateOf<NotesChapter?>(null) }
    var query by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        selected?.let { if (hindi) it.titleHi else it.titleEn }
                            ?: t(hindi, "Parmar Geography नोट्स", "Parmar Geography Notes")
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { if (selected != null) selected = null else nav.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepNavy, titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        val d = data
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (d == null) {
                Text(t(hindi, "लोड हो रहा है…", "Loading…"), Modifier.padding(16.dp))
                return@Column
            }
            val chapter = selected
            if (chapter == null) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    placeholder = { Text(t(hindi, "अध्याय या तथ्य खोजें…", "Search chapters or facts…")) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true
                )
                Text(
                    t(
                        hindi,
                        "कुल ${d.notesChapters.size} अध्याय • ${d.notesChapters.sumOf { it.bullets.size }} तथ्य • स्रोत: आपका Parmar Geography PDF (हस्तलिखित नोट्स से संकलित)",
                        "${d.notesChapters.size} chapters • ${d.notesChapters.sumOf { it.bullets.size }} facts • Source: your Parmar Geography PDF (compiled from handwritten notes)"
                    ),
                    Modifier.padding(horizontal = 14.dp), fontSize = 12.sp, color = Color(0xFF607D8B)
                )
                Spacer(Modifier.height(8.dp))
                val q = query.trim()
                val chapters = if (q.isEmpty()) d.notesChapters
                else d.notesChapters.filter { ch ->
                    ch.titleHi.contains(q, true) || ch.titleEn.contains(q, true) ||
                        ch.bullets.any { it.contains(q, true) }
                }
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    items(chapters) { ch ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F2F1)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                                .clickable { selected = ch }
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("📚", fontSize = 24.sp)
                                Column(Modifier.padding(start = 12.dp).weight(1f)) {
                                    Text(if (hindi) ch.titleHi else ch.titleEn, fontWeight = FontWeight.Bold, fontSize = 15.5.sp)
                                    Text(
                                        "${ch.bullets.size} " + t(hindi, "तथ्य", "facts") + " • ${ch.source}",
                                        fontSize = 11.5.sp, color = Color(0xFF546E7A)
                                    )
                                }
                                Text("›", fontSize = 24.sp, color = Color(0xFF00897B))
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                    item {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            chapter.source + " • " + chapter.bullets.size + " " + t(hindi, "तथ्य", "facts"),
                            fontSize = 12.sp, color = Color(0xFF607D8B)
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    items(chapter.bullets) { bullet ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Text("•", color = Color(0xFF00897B), fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 8.dp))
                            Text(bullet, fontSize = 14.5.sp, lineHeight = 20.sp)
                        }
                    }
                    item {
                        Spacer(Modifier.height(14.dp))
                        Text(
                            t(
                                hindi,
                                "💡 टिप: इस अध्याय के प्रश्न 'क्विज़' टैब में 'Parmar नोट्स क्विज़' मोड में मिलेंगे।",
                                "Tip: Questions from this chapter appear in the Quiz tab under 'Parmar Notes Quiz'."
                            ),
                            fontSize = 12.5.sp, color = Color(0xFF546E7A)
                        )
                        Spacer(Modifier.height(20.dp))
                    }
                }
            }
        }
    }
}
