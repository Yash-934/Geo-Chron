package com.geochron.atlas.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.geochron.atlas.AppViewModel
import com.geochron.atlas.data.GeoFeature
import com.geochron.atlas.data.formatYear
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimelineScreen(nav: NavController, vm: AppViewModel) {
    val data by vm.data.collectAsState()
    val hindi by vm.hindi.collectAsState()
    val dark by vm.dark.collectAsState()

    var year by remember { mutableIntStateOf(-250) }
    var playing by remember { mutableStateOf(false) }
    var mapScope by remember { mutableStateOf("india") }
    var selectedDatasetId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(playing) {
        while (playing) {
            delay(90)
            year += 12
            if (year >= 2026) { year = 2026; playing = false }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(t(hindi, "इतिहास एटलस • समय रेखा", "History Atlas • Timeline")) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepNavy, titleContentColor = Color.White
                )
            )
        }
    ) { padding ->
        val d = data
        if (d == null) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        val active = remember(year, d) { d.history.filter { it.contains(year) } }
        val selectedDataset = d.history.firstOrNull { it.id == selectedDatasetId }
            ?: active.firstOrNull { it.scope == mapScope } ?: active.firstOrNull()

        // Map layers: active datasets of the current map scope + their event points
        val layers = active.filter { it.scope == mapScope && it.poly != null }
            .map { EmpireLayer(it.id, if (hindi) it.hi else it.en, parseHexColor(it.colorHex), it.poly!!) }
        val eventFeatures = active.filter { it.scope == mapScope }.flatMap { ds ->
            ds.events.map { ev ->
                GeoFeature(
                    id = "event_" + ds.id + "_" + ev.en, en = ev.en, hi = ev.hi, cat = "EVENT",
                    scope = ds.scope, geomType = "point", coords = listOf(ev.lon to ev.lat),
                    infoHi = ev.infoHi, infoEn = ev.infoEn, factHi = ev.factHi, source = ds.source
                )
            }
        }
        val geo = d.boundaries[mapScope]!!

        Column(Modifier.padding(padding).fillMaxSize()) {
            // Year header + slider (3000 BCE — 2026 CE, like the design)
            Column(Modifier.fillMaxWidth().background(DeepNavy).padding(horizontal = 16.dp, vertical = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(formatYear(year), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                        Text(
                            selectedDataset?.let { (if (hindi) it.hi else it.en) + " • " + it.periodHi }
                                ?: t(hindi, "इस वर्ष हेतु डेटासेट नहीं", "No dataset for this year"),
                            color = Color(0xFFBFD9EA), fontSize = 12.sp
                        )
                    }
                    FilledIconButton(onClick = { playing = !playing }) {
                        Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = "Play/Pause")
                    }
                }
                Slider(
                    value = year.toFloat(),
                    onValueChange = { year = it.toInt(); playing = false },
                    valueRange = -3000f..2026f
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("3000 BCE", color = Color(0xFF9FB9CC), fontSize = 11.sp)
                    Text("2026 CE", color = Color(0xFF9FB9CC), fontSize = 11.sp)
                }
            }

            // Map
            Box(Modifier.fillMaxWidth().height(320.dp)) {
                AtlasMap(
                    geo = geo, dark = dark,
                    features = eventFeatures,
                    empireLayers = layers,
                    selectedFeatureId = null,
                    onFeatureTap = { f ->
                        val ds = d.history.firstOrNull { f.id.startsWith("event_" + it.id + "_") }
                        val ev = ds?.events?.firstOrNull { f.id == "event_" + ds.id + "_" + it.en }
                        if (ds != null && ev != null) vm.select(placeFromEvent(ds, ev))
                    },
                    onEmpireTap = { dsId ->
                        selectedDatasetId = dsId
                        d.history.firstOrNull { it.id == dsId }?.let { vm.select(placeFromDataset(it)) }
                    },
                    modifier = Modifier.fillMaxSize()
                )
                // Scope toggle overlay
                Row(Modifier.align(Alignment.TopEnd).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ScopeChip(t(hindi, "भारत", "India"), mapScope == "india") { mapScope = "india" }
                    ScopeChip(t(hindi, "विश्व", "World"), mapScope == "world") { mapScope = "world" }
                }
            }

            // Dataset chips — tap to jump
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (ds in d.history) {
                    val isActive = ds.contains(year)
                    val isSelected = ds.id == selectedDataset?.id
                    Card(
                        modifier = Modifier.clickable {
                            selectedDatasetId = ds.id
                            mapScope = ds.scope
                            year = ds.midYear
                        },
                        colors = CardDefaults.cardColors(
                            containerColor = when {
                                isSelected -> parseHexColor(ds.colorHex)
                                isActive -> parseHexColor(ds.colorHex).copy(alpha = 0.35f)
                                else -> Color.White
                            }
                        ),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            (if (hindi) ds.hi else ds.en),
                            fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else Color.DarkGray,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            // Context panel
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
                val ds = selectedDataset
                if (ds == null) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.padding(12.dp)) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = Color(0xFFE0A526))
                            Text(
                                t(
                                    hindi,
                                    "वर्ष $year के लिए हमारे पास सत्यापित ऐतिहासिक सीमा-डेटा उपलब्ध नहीं है। हम काल्पनिक सीमाएँ नहीं दिखाते — स्लाइडर को किसी साम्राज्य के काल तक ले जाएँ या ऊपर की चिप चुनें।",
                                    "No verified boundary dataset is available for the year $year. We do not draw invented borders — move the slider into an empire's period or tap a chip above."
                                ),
                                fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                } else {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.background(parseHexColor(ds.colorHex), RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                    Text(ds.periodHi, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(
                                    if (ds.contains(year)) t(hindi, "  •  इस वर्ष सक्रिय", "  •  Active in this year")
                                    else t(hindi, "  •  चयनित", "  •  Selected"),
                                    color = Color.Gray, fontSize = 12.sp
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(if (hindi) ds.hi else ds.en, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(if (hindi) ds.summaryHi else ds.summaryEn, fontSize = 13.5.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("⚠ " + ds.confidence, color = Color(0xFF8D6E00), fontSize = 12.sp)
                            Text(t(hindi, "स्रोत: ", "Source: ") + ds.source, color = Color.Gray, fontSize = 12.sp)
                            if (ds.events.isNotEmpty()) {
                                Spacer(Modifier.height(8.dp))
                                Text(t(hindi, "प्रमुख घटनाएँ / स्थल (मानचित्र पर टैप करें):", "Key events / sites (tap on map):"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                for (ev in ds.events) {
                                    Text("• ${if (hindi) ev.hi else ev.en} — ${ev.yearLabel}", fontSize = 13.sp,
                                        modifier = Modifier.clickable { vm.select(placeFromEvent(ds, ev)) }.padding(vertical = 3.dp))
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
        PlaceSheet(vm)
    }
}

@Composable
private fun ScopeChip(label: String, active: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (active) AtlasBlue else Color.White.copy(alpha = 0.9f)),
        shape = RoundedCornerShape(50)
    ) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (active) Color.White else Color.DarkGray,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
    }
}
