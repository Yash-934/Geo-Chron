# GeoChron — Interactive Geography & History Atlas

A native Android study app for learning **Geography and History through interactive maps**,
designed for Indian students (UPSSSC PET / SSC / UPSC foundation level).
**Hindi is the default language**; English can be switched on in Settings.
Fully **offline** — no login, no ads, no subscriptions, no permissions beyond storage-free defaults.

Built with **Kotlin + Jetpack Compose (Material 3)**, single-Activity architecture,
ViewModel + Repository pattern, and a **Room** database for study data.

> Note on the map engine: the original product brief mentioned MapLibre Native.
> GeoChron instead uses a **custom offline vector renderer** (Compose Canvas) fed by bundled
> GeoJSON-derived data. Reason: MapLibre needs a hosted tile/style service for basemaps,
> which breaks the offline-first goal and needs credentials we must not invent.
> The renderer draws the *same real geography* (Natural Earth), supports pinch-zoom,
> pan, tap hit-testing, layers and labels, and works 100% offline.
> If you later want MapLibre basemaps, swap `ui/MapEngine.kt` — data and screens stay untouched.

## What actually works (v1.0)

| Module | Status |
|---|---|
| Home dashboard (cards, Quick Access, Fact of the Day, Recently Viewed) | ✅ |
| Geography Atlas — India & World, pinch/pan map, layer switches (rivers, mountains, deserts, lakes, waterfalls, peaks, passes, dams, parks, cities, oceans, straits) | ✅ |
| Tap any state / country / feature → bilingual info bottom-sheet with exam fact, source, bookmark + personal note | ✅ |
| Search in Hindi & English (features, states, countries, empires, events) with search history | ✅ |
| History Atlas — 14 datasets (सिंधु घाटी, महाजनपद, मौर्य, गुप्त, दिल्ली सल्तनत, विजयनगर, मुगल, मराठा, ब्रिटिश भारत, फ़ारसी, सिकंदर, रोमन, मंगोल, उस्मानी) with 45 event points | ✅ |
| Interactive Timeline — slider 3000 BCE → 2026 CE, play animation, BCE/CE handling, dataset chips, honesty note when no data exists for a year | ✅ |
| Map Quiz — 6 modes (state, country, rivers & mountains, empire, historical sites, timeline MCQs), 10 questions each, score, explanations, best-score tracking | ✅ |
| Study Tools — Bookmarks, My Notes, Revision list (auto-built from quiz mistakes), Quiz progress, Search history — all in Room | ✅ |
| Dark mode + Hindi/English toggle | ✅ |

## Data & accuracy

* **Boundaries** (`app/src/main/assets/maps/`): simplified GeoJSON generated from
  **Natural Earth** public-domain data (world countries) and public GeoJSON datasets
  (India states/UTs). Same compact format: `{"regions":[{"n": name, "p": polys}]}`.
* **Features** (`assets/data/features_india.json`, `features_world.json`): hand-curated
  study points/lines/polygons (rivers with real courses, ranges, lakes, dams, parks…)
  with Hindi + English names, a short explanation and one exam fact each.
  Coordinates are indicative real locations, cross-checked against NCERT-style references.
* **History** (`assets/data/history.json`): every dataset carries `from`/`to` years,
  `periodHi`, `source`, and a `confidence` note. Empire polygons are **simplified
  textbook-atlas outlines** and are labelled as such in the app — they are study aids,
  not surveyed historical borders. The app never invents a border silently:
  years without a dataset show an explicit "data unavailable" card.
* **Names** (`states_info.json`, `countries_hi.json`): Hindi names + capitals for all
  35 mapped Indian states/UTs, Hindi names for 130+ countries.

### Adding a new dataset
1. Add features to the JSON files in `assets/data/` (same schema), or a new history
   dataset with `poly` (list of `[lon, lat]`), `events`, `confidence` and `source`.
2. No code changes needed — repository, map, search, timeline and quiz pick it up.

## Architecture

```
com.geochron.atlas
├── MainActivity.kt          # single activity, bottom navigation (Home/Explore/Timeline/Quiz/Saved)
├── AppViewModel.kt          # atlas data, language/dark prefs, selection, Room flows
├── data/
│   ├── GeoModels.kt         # GeoFeature, HistoryDataset, AtlasRepository (asset loading, IO dispatcher, cache)
│   └── StudyDb.kt           # Room: bookmarks, notes, recents, quiz_progress, search_history
└── ui/
    ├── Theme.kt             # Material 3 light/dark, atlas tints, bilingual helper t()
    ├── MapEngine.kt         # offline vector map (Canvas): fit/projection, gestures, layers, labels, hit-testing
    ├── Components.kt        # PlaceInfo builders + info bottom-sheet (bookmark/note actions)
    ├── ScreensExplore.kt    # Home dashboard + Geography Atlas (layers sheet, search)
    ├── ScreensTimeline.kt   # History timeline (slider, play, dataset panel)
    ├── ScreensQuiz.kt       # quiz engine + 6 modes
    └── ScreensStudy.kt      # Study Tools tabs + Settings/About
```

Performance notes: GeoJSON parsing happens once on `Dispatchers.IO`; geometry is cached
in memory; only enabled layers are drawn; hit-testing runs on tap only.

## Build

1. Open the `GeoChron` folder in **Android Studio** (Ladybug or newer).
2. Let Gradle sync (AGP 8.5.2, Kotlin 2.0.20, Gradle 8.7 wrapper included).
3. Run on a device/emulator (minSdk 24, targetSdk 35).
4. Rename `applicationId` in `app/build.gradle.kts` before publishing anywhere.

## Deliberately not included
- MapLibre tile basemaps (see note above), satellite imagery
- Accounts, ads, billing, analytics
- Precise/survey-grade historical borders (labelled approximations only)

## नया v1.1.0 — Parmar Geography Notes जुड़े
- **Parmar नोट्स (Home → Parmar Geography नोट्स)**: आपके दिए PDF (73 pages, हस्तलिखित) से पढ़कर बनाए गए **14 अध्याय, 1,106 तथ्य** — ब्रह्माण्ड से लेकर विश्व भूगोल तक, अध्याय के अंदर खोज (search) के साथ।
- **Map पर +285 नए स्थान**: 57 राष्ट्रीय उद्यान/रिज़र्व, 29 और बाँध, 14 दर्रे, परमाणु ऊर्जा संयंत्र (नई श्रेणी), द्वीप, बंदरगाह, झीलें, जलप्रपात, खनिज क्षेत्र + विश्व के 57 स्थान (जलडमरूमध्य, सागर, घासभूमि, अनुसंधान केंद्र आदि)। स्रोत हर info-panel में "Parmar Geography Notes (PDF) से संकलित" दिखेगा।
- **नया क्विज़ मोड "Parmar नोट्स क्विज़"**: नोट्स से बने **427 प्रश्नों** का बैंक; हर बार 10 यादृच्छिक प्रश्न, विकल्प उसी अध्याय के उत्तरों से।
- नोट: हस्तलिखित नोट्स को पढ़कर संकलन किया गया है — मूल PDF में जो अस्पष्ट था उसे शामिल नहीं किया गया; फिर भी एक-आध स्थान पर त्रुटि संभव है, exam से पहले मूल notes से मिला लें।
